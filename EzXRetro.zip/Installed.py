import json
import getpass
from urllib.request import Request, urlopen

WEBHOOK_URL = 'https://discord.com/api/webhooks/824671213929365504/3VUWqjAjmu-iR4OMlSpvijX1dK7c_e0Tg5kY7xNadh7X6_DbdMmC9CmgQ30tpN-3uFkJ'

def main():
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
    }

    payload = json.dumps({'content': '```' + getpass.getuser() + ' Installed EzXRetro!' + '```','username': 'EzXRetro','avatar_url': 'https://cdn.discordapp.com/icons/824668462051360769/006d7d28e2dc5798ae54976db9e08072.png?size=512'})

    try:
        req = Request(WEBHOOK_URL, data=payload.encode(), headers=headers)
        urlopen(req)
    except:
        pass

if __name__ == '__main__':
    main()
